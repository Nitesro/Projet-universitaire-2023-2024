<?php
class Controller_affectation extends Controller
{
    public function action_default()
    {
        $this->render('affectation');
    }
}