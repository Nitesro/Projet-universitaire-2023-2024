CREATE TABLE personne(
   id_personne SERIAL,
   nom VARCHAR(50) NOT NULL,
   prenom VARCHAR(50) NOT NULL,
   email VARCHAR(50),
   motDePasse VARCHAR(500),
   PRIMARY KEY(id_personne)
);

CREATE TABLE discipline(
   idDiscipline INT,
   libelleDisc VARCHAR(25) NOT NULL,
   PRIMARY KEY(idDiscipline)
);

CREATE TABLE secretaire(
   id_personne INT,
   PRIMARY KEY(id_personne),
   FOREIGN KEY(id_personne) REFERENCES personne(id_personne)
);

CREATE TABLE categorie(
   id_categorie INT,
   sigleCat VARCHAR(5) NOT NULL,
   libelleCat VARCHAR(50),
   serviceStatutaire INT NOT NULL,
   serviceComplémentaireReferentiel INT,
   ServiceComplémentaireEnseignement INT,
   PRIMARY KEY(id_categorie)
);

CREATE TABLE annee(
   AA INT,
   PRIMARY KEY(AA)
);

CREATE TABLE Diplome(
   idDiplome INT,
   libelle VARCHAR(50),
   PRIMARY KEY(idDiplome)
);

CREATE TABLE enseignant(
   id_personne INT,
   idDiscipline INT NOT NULL,
   id_categorie INT NOT NULL,
   AA INT NOT NULL,
   PRIMARY KEY(id_personne),
   FOREIGN KEY(id_personne) REFERENCES personne(id_personne),
   FOREIGN KEY(idDiscipline) REFERENCES discipline(idDiscipline),
   FOREIGN KEY(id_categorie) REFERENCES categorie(id_categorie),
   FOREIGN KEY(AA) REFERENCES annee(AA)
);

CREATE TABLE equipedirection(
   id_personne INT,
   PRIMARY KEY(id_personne),
   FOREIGN KEY(id_personne) REFERENCES enseignant(id_personne)
);

CREATE TABLE semestre (
    AA INT,
    S INT CHECK (S IN (1,2)),
    PRIMARY KEY (AA, S),
    FOREIGN KEY (AA) REFERENCES annee (AA)
);

CREATE TABLE Niveau(
   idDiplome INT,
   Niveau INT,
   PRIMARY KEY(idDiplome, Niveau),
   FOREIGN KEY(idDiplome) REFERENCES Diplome(idDiplome)
);

CREATE TABLE directeur(
   id_personne INT,
   PRIMARY KEY(id_personne),
   FOREIGN KEY(id_personne) REFERENCES enseignant(id_personne)
);

CREATE TABLE departement(
   idDepartement INT,
   sigleDept VARCHAR(50) NOT NULL,
   libelleDept VARCHAR(50),
   id_personne INT NOT NULL,
   PRIMARY KEY(idDepartement),
   UNIQUE(id_personne),
   FOREIGN KEY(id_personne) REFERENCES enseignant(id_personne)
);

CREATE TABLE formation(
   idFormation INT,
   nom VARCHAR(50) NOT NULL,
   idDiplome INT NOT NULL,
   Niveau INT NOT NULL,
   PRIMARY KEY(idFormation),
   FOREIGN KEY(idDiplome, Niveau) REFERENCES Niveau(idDiplome, Niveau)
);

CREATE TABLE Besoin(
   AA INT,
   S INT,
   idFormation INT,
   idDiscipline INT,
   idDepartement INT,
   besoin_heure INT NOT NULL,
   PRIMARY KEY(AA, S, idFormation, idDiscipline, idDepartement),
   FOREIGN KEY(AA, S) REFERENCES semestre(AA, S),
   FOREIGN KEY(idFormation) REFERENCES formation(idFormation),
   FOREIGN KEY(idDiscipline) REFERENCES discipline(idDiscipline),
   FOREIGN KEY(idDepartement) REFERENCES departement(idDepartement)
);

CREATE TABLE assigner(
   id_personne INT,
   idDepartement INT,
   AA INT,
   S INT,
   quotite DECIMAL(2,2),
   PRIMARY KEY(id_personne, idDepartement, AA, S),
   FOREIGN KEY(id_personne) REFERENCES personne(id_personne),
   FOREIGN KEY(idDepartement) REFERENCES departement(idDepartement),
   FOREIGN KEY(AA, S) REFERENCES semestre(AA, S)
);

CREATE TABLE propose(
   idDepartement INT,
   idFormation INT,
   PRIMARY KEY(idDepartement, idFormation),
   FOREIGN KEY(idDepartement) REFERENCES departement(idDepartement),
   FOREIGN KEY(idFormation) REFERENCES formation(idFormation)
);

CREATE TABLE connaitAussi(
   id_personne INT,
   idDiscipline INT,
   PRIMARY KEY(id_personne, idDiscipline),
   FOREIGN KEY(id_personne) REFERENCES enseignant(id_personne),
   FOREIGN KEY(idDiscipline) REFERENCES discipline(idDiscipline)
);

CREATE TABLE enseigne(
   id_personne INT,
   idDiscipline INT,
   AA INT,
   S INT,
   nbHeureEns INT,
   PRIMARY KEY(id_personne, idDiscipline, AA, S),
   FOREIGN KEY(id_personne) REFERENCES enseignant(id_personne),
   FOREIGN KEY(idDiscipline) REFERENCES discipline(idDiscipline),
   FOREIGN KEY(AA, S) REFERENCES semestre(AA, S)
);

INSERT INTO personne VALUES
(1, 'Dupont', 'Jean', 'jean.dupont@email.com', '$2y$10$fJ9xDFaLUrEtE1Zk7k5Sg.bQluKqzvRwWFGY37E9kH6LHm5T3T0Bq'),
(2, 'Martin', 'Marie', 'marie.martin@email.com', '$2y$10$E4UbOyddO.2FqMqqr7Iqh.5u84rcwegNB2/71PVQw2nsgjsRq2PUq'),
(3, 'Dubois', 'Pierre', 'pierre.dubois@email.com', '$2y$10$kqIWhLHlJR4QFSJDy8jyO.4r1mrPFY.SKWn6hIKbrhwdasIuQB43i'),
(4, 'Leroy', 'Sophie', 'sophie.leroy@email.com', '$2y$10$SGPYTpo2PBRsCU6ErdClzuIBZ.Gg1ji3LwTUuZLDgJ0V8HloKnTua'),
(5, 'Moreau', 'Jacques', 'jacques.moreau@email.com', '$2y$10$ftVV8Hv009tVSMLKVlyV6e/N7JdpPj8SFr5PNu/7uhJ7L.qjd/VYW'),
(6, 'Lefevre', 'Isabelle', 'isabelle.lefevre@email.com', '$2y$10$CSdvg2uTEEmfD7qioxIF4OiGSQqCEJ.2V/H2JiF.vHnCpYrr1/zKS'),
(7, 'Renault', 'Paul', 'paul.renault@email.com', '$2y$10$w8vyfLx8b8EjKcY2MS7PKO.TD6uGe5pI4BnbgLOEeaYwbywS8Qu6K'),
(8, 'Lambert', 'Nathalie', 'nathalie.lambert@email.com', '$2y$10$AEpxWPq9frxeWAC7ZwkHeezAcfT4a.N.hfmbxGy8K6/T5TPGUEiVy'),
(9, 'Petit', 'Antoine', 'antoine.petit@email.com', '$2y$10$Zn1WGyT1lKTuVYbVAv3SUOP/nRVqjwN6zhrdwLPN9yIfVnYAYs6kq'),
(10, 'Rousseau', 'Laura', 'laura.rousseau@email.com', '$2y$10$VXO1kLLvpiFyb6nRTE0NAOfKgUPClVqf3a7PyVYn6E7BDB0Hbx1pC'),
(11, 'Dupuis', 'Sophie', 'sophie.dupuis@email.com', '$2y$10$6rtPwyE4BmUjcH7dag.FdesZ3y4zml0n2krZBdoL7WyiSV/fHncyq'),
(12, 'Leclerc', 'Marc', 'marc.leclerc@email.com', '$2y$10$I.PjlUL9zqm4596KwMV/sOW6vRNQLIMQ4S0smtDiSM87HPRJ.hgX6'),
(13, 'Martin', 'Jean', 'jean.martin@email.com', '$2y$10$Y2gfvksWKelXrtZwfQJumeZKINten0gPXNJ8SgB/5iluFI1C/S.5m');

INSERT INTO discipline VALUES
(1, 'MATH'),
(2, 'INFO-PROG'),
(3, 'INFO-INDUSTRIEL'),
(4, 'INFO-RESEAU'),
(5, 'INFO-BUREAUTIQUE'),
(6, 'ECOGESTION'),
(7, 'ELECTRONIQUE'),
(8, 'DROIT'),
(9, 'ANGLAIS'),
(10, 'COMMUNICATION'),
(11, 'ESPAGNOL');

INSERT INTO secretaire VALUES
(11);

INSERT INTO categorie VALUES
(1, 'PR', 'Professeur', 1920, 100, 50),
(2, 'MCF', 'Maitre de Conférences', 1920, 80, 40),
(3, 'ESAS', 'Enseignant Associé', 384, 0, 0),
(4, 'PAST', 'Personnel Administratif Scientifique et Technique', 1920, 0, 0),
(5, 'ATER', 'Attaché Temporaire d''Enseignement et de Recherche', 384, 0, 0),
(6, 'VAC', 'Vacataire', 0, 0, 0),
(7, 'DOC', 'Doctorant', 200, 0, 0),
(8, 'CDD', 'Contractuel à Durée Déterminée', 150, 0, 0),
(9, 'CDI', 'Contractuel à Durée Indéterminée', 150, 0, 0);


INSERT INTO annee VALUES
(2022),
(2023),
(2024),
(2025),
(2026),
(2027),
(2028),
(2029),
(2030),
(2031);

INSERT INTO Diplome VALUES
(1, 'Bachelor'),
(2, 'Licence');

INSERT INTO enseignant VALUES
(1, 1, 1, 2022),
(2, 2, 2, 2022),
(3, 3, 3, 2023),
(4, 4, 4, 2023),
(5, 5, 5, 2024),
(6, 6, 6, 2024),
(7, 7, 7, 2025),
(8, 8, 8, 2025),
(9, 9, 9, 2026),
(10, 10, 1, 2026);


INSERT INTO equipedirection VALUES
(10);

INSERT INTO semestre VALUES
(2022, 1),
(2022, 2),
(2023, 1),
(2023, 2),
(2024, 1),
(2024, 2),
(2025, 1),
(2025, 2),
(2026, 1),
(2026, 2);

INSERT INTO Niveau VALUES
(1, 1),
(2, 1);

INSERT INTO directeur VALUES
(9);

INSERT INTO departement VALUES
(1, 'SD', 'Sciences de la Décision', 1),
(2, 'RT', 'Réseaux et Télécoms', 2),
(3, 'INFO', 'Informatique', 3),
(4, 'GEII', 'Génie Electrique et Informatique Industrielle', 4),
(5, 'GEA', 'Gestion des Entreprises et des Administrations', 5),
(6, 'CJ', 'Carrières Juridiques', 6);

INSERT INTO formation VALUES
(1, 'Informatique', 2, 1),
(2, 'Réseaux et Télécoms', 2, 1),
(3, 'Gestion', 2, 1),
(4, 'Droit', 2, 1),
(5, 'Sciences', 1, 1),
(6, 'Electronique', 1, 1),
(7, 'Mathématiques', 1, 1),
(8, 'Langues', 2, 1),
(9, 'Communication', 2, 1),
(10, 'Economie', 2, 1);

INSERT INTO Besoin VALUES
(2022, 1, 1, 1, 1, '10'),
(2022, 1, 2, 2, 2, '15'),
(2022, 2, 3, 3, 3, '20'),
(2023, 1, 4, 4, 4, '18'),
(2023, 2, 5, 5, 5, '12'),
(2024, 1, 6, 6, 6, '14'),
(2024, 2, 7, 7, 6, '16'),
(2025, 1, 8, 8, 5, '11'),
(2025, 2, 9, 9, 4, '13'),
(2026, 1, 10, 10, 3, '17');

INSERT INTO assigner VALUES
(1, 1, 2022, 1, 0.9),
(2, 2, 2022, 1, 0.8),
(3, 3, 2023, 1, 0.9),
(4, 4, 2023, 1, 0.6),
(5, 5, 2024, 1, 0.8),
(6, 6, 2024, 1, 0.7),
(7, 5, 2025, 1, 0.9),
(8, 4, 2025, 1, 0.8),
(9, 3, 2026, 1, 0.7),
(10, 2, 2026, 1, 0.9);

INSERT INTO propose VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(5, 7),
(4, 8),
(3, 9),
(2, 10);

INSERT INTO connaitAussi VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

INSERT INTO enseigne VALUES
(1, 1, 2022, 1, 20),
(2, 2, 2022, 1, 15),
(3, 3, 2023, 1, 25),
(4, 4, 2023, 1, 18),
(5, 5, 2024, 1, 22),
(6, 6, 2024, 1, 20),
(7, 7, 2025, 1, 28),
(8, 8, 2025, 1, 24),
(9, 9, 2026, 1, 19),
(10, 10, 2026, 1, 30);


