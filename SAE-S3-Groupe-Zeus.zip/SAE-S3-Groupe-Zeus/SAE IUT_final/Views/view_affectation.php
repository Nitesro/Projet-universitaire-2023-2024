<?php
$title= 'Affectation';
require_once 'view_begin.php';
?>

<div class="affectation">
<h1>Fonctionnalité à venir</h1>

</div>
