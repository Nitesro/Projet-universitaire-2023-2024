<?php
$dsn= "pgsql:host=localhost;dbname=sae";
$login= "postgres";
$mdp = "admin";
?>