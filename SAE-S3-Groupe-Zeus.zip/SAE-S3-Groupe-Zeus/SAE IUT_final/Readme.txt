le compte directeur: l'identifiant = antoine.petit@email.com mdp = antoine123
le compte enseignant l'identifiant = jean.dupont@email.com mdp= password123
