<?php

define("NB_RESULTATS_PAR_PAGE", 25);
