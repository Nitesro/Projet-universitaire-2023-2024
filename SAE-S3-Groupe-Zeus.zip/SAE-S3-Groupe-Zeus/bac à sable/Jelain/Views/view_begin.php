<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<title> Auto-formation - Voiture</title>
		<link rel="stylesheet" href="Content/css/style.css"/>
	</head>
	<body>
		<nav>
			<ul>
				<li><a href="?"> Nos voitures</a></li>
				<li><a href="?controller=add&action=form_add"> Ajouter une nouvelle voiture</a></li>
			</ul>
		</nav>

		<main>