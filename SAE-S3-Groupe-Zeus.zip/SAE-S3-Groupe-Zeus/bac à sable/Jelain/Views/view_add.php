<?php require "view_begin.php"; ?>


<div class="add">

<h1> Ajouter une nouvelle voiture </h1>
<div class="form">
<form action = "?controller=add&action=add" method="post">
    <input type="text" name="marque" placeholder="Marque"/>
    <input type="text" name="modele" placeholder="Modéle"/>
    <input type="number" name="annee" placeholder="Année"/>
    <input type="number" name="prix" placeholder="Prix"/>
    <input type="text" name="imageurl" placeholder="Image"/>

    <input type="submit" value="Ajouter"/>
</form>
</div>



</div>


<?php require "view_end.php"; ?>