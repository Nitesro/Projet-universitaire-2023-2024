<?php require "view_begin.php";?>
<div class="home">
<h1> Nos voitures </h1>
<ul>
<?php
foreach($voitures as $voiture){
    $url = $voiture['imageurl'];
    echo "<li> Marque: ".$voiture['marque'] . 
        "<br>Modele: " .$voiture['modele']. 
        "<br>Année: " . $voiture['annee'].
        "<br>Prix: " . $voiture['prix']. " €".
        "<br><img src=\"" . $voiture['imageurl'] . "\">" . 
        "</li>";
}
?>
</ul>
</div>
<?php require "view_end.php"; ?>

