<?php
class Controller_add extends Controller
{

    public function action_form_add()
    {
        $m = Model::getModel();
        $data = [
        ];
        $this->render("add", $data);
    }

    public function action_default()
    {
        $this->action_form_add();
    }

    public function action_add()
    {
        $ajout = false;

        //Test si les informations nécessaires sont fournies
        if ((isset($_POST["marque"]))
            and isset($_POST["modele"])
            and isset($_POST["annee"])) {
            // On vérifie que la catégorie est une des catégories possibles
    
                // Préparation du tableau infos
                $infos = [];
                $noms = ['marque', 'modele', 'annee', 'prix','imageurl'];
                foreach ($noms as $v) {
                    if (isset($_POST[$v])) {
                        $infos[$v] = $_POST[$v];
                    } else {
                        $infos[$v] = null;
                    }
                }

                //Récupération du modèle
                $m = Model::getModel();
                //Ajout du prix nobel dans la base
                $ajout = $m->addCar($infos);
        }

        //Préparation de $data pour l'affichage de la vue message
        $data = [
            "title" => "Ajout de la voiture",
        ];
        if ($ajout) {
            $data["message"] = "Votre voiture a été ajouté avec succes";
        } else {
            $data["message"] = "Il y a eu un problème ! La voiture n'a pas pu être ajouté";
        }
        $this->render("message", $data);
    }


}

?>