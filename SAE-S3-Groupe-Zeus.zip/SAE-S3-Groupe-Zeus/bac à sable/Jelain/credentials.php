<?php
$dsn = 'pgsql:host=localhost;dbname=auto_formation';
$login = 'jelain';
$mdp = '28Juin1978';
?>