-- Table pour les moteurs
CREATE TABLE Moteur (
    id SERIAL PRIMARY KEY,
    nom VARCHAR NOT NULL,
    carburant VARCHAR,
    puissance INT
);

-- Ajout de données pour la table Moteur
INSERT INTO Moteur(nom, carburant, puissance) VALUES
('1.9dci', 'Diesel', 130),
('E-Tech EV60', 'Electrique', 220),
('1.3 Mild Hybrid', 'Hybride', 160),
('1.2 Puretech', 'Essence', 130),
('2.0 BlueHDI', 'Diesel', 150),
('1.8 Puretech', 'Essence', 180);


-- Table pour les voitures
CREATE TABLE Voiture (
    id SERIAL PRIMARY KEY,
    marque VARCHAR NOT NULL,
    modele VARCHAR NOT NULL,
    annee INT NOT NULL,
    prix INT NOT NULL,
    moteurid INT,
    imageurl VARCHAR, -- Ajout de la colonne pour l'URL de l'image
    FOREIGN KEY (moteurid) REFERENCES Moteur(id)
);

INSERT INTO Voiture(marque, modele, annee, prix, moteurid, imageurl) VALUES
('Renault', 'Megane', 2010, 8999, 1, 'Content/img/voitures/megane_3.jpeg'),
('Renault', 'Megane e-tech', 2023, 37999, 2, 'Content/img/voitures/megane_etech.jpeg'),
('Renault', 'Austral', 2023, 31999, 3, 'Content/img/voitures/austral.jpeg'),
('Renault', 'Espace', 2023, 45699, 3, 'Content/img/voitures/espace_vi.jpeg'),
('Renault', 'Scenic', 2011, 9999, 1, 'Content/img/voitures/scenic_3.jpeg'),
('Nissan', 'Primera', 2006, 5999, 1, 'Content/img/voitures/primera.jpeg'),
('Peugeot', '3008', 2020, 45999, 4, 'Content/img/voitures/3008.webp'),
('Peugeot', '3008', 2020, 58799, 5, 'Content/img/voitures/3008.webp'),
('Peugeot', '3008', 2020, 58799, 6, 'Content/img/voitures/3008.webp'),
('Citroen', 'DS3', 2023, 61799, 4, 'Content/img/voitures/ds3.png');

