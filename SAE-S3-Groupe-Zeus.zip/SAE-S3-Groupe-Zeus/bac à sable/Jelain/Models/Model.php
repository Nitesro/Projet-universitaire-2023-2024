<?php

class Model
{
    /**
     * Attribut contenant l'instance PDO
     */
    private $bd;

    /**
     * Attribut statique qui contiendra l'unique instance de Model
     */
    private static $instance = null;

    /**
     * Constructeur : effectue la connexion à la base de données.
     */
    private function __construct()
    {
        include "/Applications/XAMPP/xamppfiles/htdocs/public_html/SAE2/MVC/credentials.php";
        $this->bd = new PDO($dsn, $login, $mdp);
        $this->bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->bd->query("SET nameS 'utf8'");
    }

    /**
     * Méthode permettant de récupérer un modèle car le constructeur est privé (Implémentation du Design Pattern Singleton)
     */
    public static function getModel()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Retourne toutes les voitures
     * @return [array] Contient les informations des voitures
     */
    public function getAllCars()
    {
        $req = $this->bd->prepare('SELECT * FROM Voiture');
        $req->execute();
        return $req->fetchall();
    }



    /**
     * Ajoute une voiture passé en paramètre dans la base de données.
     * @return [boolean] retourne true si la personne a été ajoutée dans la base de données, et false sinon
     */
    public function addCar($infos)
    {
        //Préparation de la requête
        $requete = $this->bd->prepare('INSERT INTO Voiture(marque, modele, annee, prix, imageurl) VALUES (:marque, :modele, :annee, :prix, :imageurl)');

        //Remplacement des marqueurs de place par les valeurs
        $marqueurs = ['marque', 'modele', 'annee', 'prix','imageurl'];
        foreach ($marqueurs as $value) {
            $requete->bindValue(':' . $value, $infos[$value]);
        }

        //Exécution de la requête
        $requete->execute();

        return (bool) $requete->rowCount();
    }


}
