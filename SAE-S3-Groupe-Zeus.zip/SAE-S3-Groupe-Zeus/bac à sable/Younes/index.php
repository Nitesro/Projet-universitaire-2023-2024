<?php


// Inclure les dépendances
include 'model.php';
include 'controller.php';
include 'view.php';

// Instancier le contrôleur
$controller = new BibliothequeController();

// Déterminer quelle action doit être effectuée en fonction des paramètres d'URL
$action = isset($_GET['action']) ? $_GET['action'] : 'listerLivres';

// Exécuter l'action correspondante
if ($action === 'listerLivres') {
    $controller->listerLivres();
} elseif ($action === 'emprunterLivre') {
    if (isset($_GET['livre']) && isset($_GET['emprunteur'])) {
        $livreId = htmlspecialchars($_GET['livre']);
        $emprunteurId = htmlspecialchars($_GET['emprunteur']);
        $controller->emprunterLivre($livreId, $emprunteurId);
    } else {
        afficherErreur("Paramètres manquants pour l'emprunt.");
    }
} else {
    afficherErreur("Action non reconnue.");
}
