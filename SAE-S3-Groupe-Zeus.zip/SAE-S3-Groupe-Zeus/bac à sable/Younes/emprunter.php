<?php
include 'controller.php';

// Exemple d'utilisation du contrôleur pour l'emprunt d'un livre
$controller = new BibliothequeController();

if (isset($_GET['livre']) && isset($_GET['emprunteur'])) {
    $livreId = htmlspecialchars($_GET['livre']);
    $emprunteurId = htmlspecialchars($_GET['emprunteur']);
    $controller->emprunterLivre($livreId, $emprunteurId);
} else {
    afficherErreur("Paramètres manquants pour l'emprunt.");
}
