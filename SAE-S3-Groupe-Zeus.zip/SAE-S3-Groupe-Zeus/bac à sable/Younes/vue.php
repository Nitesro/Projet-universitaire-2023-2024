<?php
function afficherLivres($livres) {
    echo "<h1>Liste des Livres</h1>";
    if (empty($livres)) {
        echo "<p>Aucun livre disponible pour le moment.</p>";
    } else {
        echo "<ul>";
        foreach ($livres as $livre) {
            echo "<li>{$livre->Titre} ({$livre->Annee_Publication}) ";
            echo "<a href='emprunter.php?livre={$livre->ID_Livre}'>Emprunter</a></li>";
        }
        echo "</ul>";
    }
}

function afficherMessage($message) {
    echo "<p class='success'>$message</p>";
}

function afficherErreur($erreur) {
    echo "<p class='error'>$erreur</p>";
}
