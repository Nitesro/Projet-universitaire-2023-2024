<?php
include 'model.php';

class BibliothequeController {
    public function listerLivres() {
        try {
            // Logique pour récupérer la liste des livres depuis la base de données
            // (utiliser des requêtes SQL sécurisées, ORM, etc.)
            $livres = []; // Remplacez cela par la logique réelle

            // Affichage de la liste des livres
            include 'view.php';
            afficherLivres($livres);
        } catch (Exception $e) {
            afficherErreur($e->getMessage());
        }
    }

    public function emprunterLivre($livreId, $emprunteurId) {
        try {
            // Logique pour enregistrer un nouvel emprunt dans la base de données
            // (utiliser des requêtes SQL sécurisées, ORM, etc.)

            // Affichage d'un message de succès
            include 'view.php';
            afficherMessage("L'emprunt a été enregistré avec succès.");
        } catch (Exception $e) {
            afficherErreur($e->getMessage());
        }
    }
}

// Exemple d'utilisation du contrôleur
$controller = new BibliothequeController();
$controller->listerLivres();
