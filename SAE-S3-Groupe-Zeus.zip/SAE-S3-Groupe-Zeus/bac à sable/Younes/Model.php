<?php
class Auteur {
    public $ID_Auteur;
    public $Nom;
    public $Prenom;
    public $Date_Naissance;
}

class Livre {
    public $ID_Livre;
    public $Titre;
    public $AuteurID;
    public $Annee_Publication;
    public $ISBN;
}

class Emprunteur {
    public $ID_Emprunteur;
    public $Nom;
    public $Prenom;
    public $Date_Naissance;
    public $Adresse;
}

class Emprunt {
    public $ID_Emprunt;
    public $ID_Livre;
    public $ID_Emprunteur;
    public $Date_Emprunt;
    public $Date_Retour;
}
