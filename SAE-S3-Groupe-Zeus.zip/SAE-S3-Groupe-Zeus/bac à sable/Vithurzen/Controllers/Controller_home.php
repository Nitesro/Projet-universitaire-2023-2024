<?php 

class Controller_home extends Controller {

    public function action_default() {
        $m = Model::getModel();
        $actor = $m->getActor();
        $tab = [
            "actor" => $actor,
        ];
        $this->render("home", $tab);
        
    } 
}

?>