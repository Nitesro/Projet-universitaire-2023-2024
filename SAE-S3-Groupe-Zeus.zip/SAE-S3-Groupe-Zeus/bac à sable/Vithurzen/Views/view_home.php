<?php require "view_begin.php"; ?>

<h1>Liste des acteurs</h1>

<?php


foreach ($actor as $value) {
    echo $value[1] ." ". $value[2]; ?> <br/>
<?php
}
?>

<?php require "view_end.php"; ?>