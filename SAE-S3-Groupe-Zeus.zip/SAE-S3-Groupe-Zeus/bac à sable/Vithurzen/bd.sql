CREATE TABLE film(
    id_film SERIAL PRIMARY KEY,
    title VARCHAR,
    realisateur VARCHAR,
    annee INTEGER
);

CREATE TABLE acteur(
    id_acteur SERIAL PRIMARY KEY,
    nom VARCHAR,
    prenom VARCHAR
);

INSERT INTO film (title, realisateur, annee)
VALUES
('The Shawshank Redemption', 'Frank Darabont', 1994),
('Inception', 'Christopher Nolan', 2010),
('The Godfather', 'Francis Ford Coppola', 1972),
('Pulp Fiction', 'Quentin Tarantino', 1994),
('The Dark Knight', 'Christopher Nolan', 2008);

INSERT INTO acteur (nom, prenom)
VALUES
('Morgan', 'Freeman'),
('Leonardo', 'Dicaprio'),
('Marlon', 'Brando'),
('John', 'Travolta'),
('Christian', 'Bale');

SELECT * FROM film;
SELECT * FROM acteur;



