<?php

$dsn= "pgsql:host=aquabdd;dbname=etudiants";
$login= "12203457";
$mdp = "173078346BF";



?>