<?php
// index.php

include 'controller.php';

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application de Cocktails</title>
</head>
<body>

    <h1>Recherche de Cocktails</h1>

    <!-- Formulaire de recherche -->
    <form action="controller.php" method="post">
        <input type="hidden" name="action" value="search">
        <label for="query">Nom du Cocktail :</label>
        <input type="text" name="query" id="query" required>
        <button type="submit">Rechercher</button>
    </form>

    <hr>

    <!-- Résultats de la recherche -->
    <?php
    if (isset($_POST['action']) && $_POST['action'] == 'search') {
        $cocktailModel = new CocktailModel($conn);

        $query = $_POST['query'];

        $cocktails = $cocktailModel->searchCocktail($query);

        $view = new CocktailView();
        $view->showCocktails($cocktails);
    }
    ?>

</body>
</html>