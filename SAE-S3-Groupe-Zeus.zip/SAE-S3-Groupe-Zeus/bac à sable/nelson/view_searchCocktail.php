<?php
// view.php

class CocktailView {
    public function showCocktails($cocktails) {
        if (!empty($cocktails)) {
            echo "<h2>Liste des Cocktails</h2>";
            echo "<ul>";
            foreach ($cocktails as $cocktail) {
                echo "<li>{$cocktail['nom']}</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>Aucun cocktail trouvé.</p>";
        }
    }

    public function showErrorMessage($message) {
        echo "<div style='color: red;'>Erreur : $message</div>";
    }

    public function showSuccessMessage($message) {
        echo "<div style='color: green;'>Succès : $message</div>";
    }
}
?>

