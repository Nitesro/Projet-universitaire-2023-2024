<?php
// model.php

class CocktailModel {
    private $conn;

    private function __construct($conn) {
        $this->conn = $conn;
    }

    public static function create($conn) {
        return new self($conn);
    }


    public function searchCocktail($query) {
        $query = $this->secureInput($query);

        $sql = "SELECT * FROM Cocktails WHERE nom ILIKE :query";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':query', $query, PDO::PARAM_STR);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result) {
            return $result;
        } else {
            return false;
        }
    }


    public function addCocktail($nom, $alcool_1, $alcool_2, $alcool_3, $boisson_soft_1, $boisson_soft_2, $boisson_soft_3, $garniture_1, $garniture_2, $garniture_3, $pourcentage_alcool) {
        $nom = $this->secureInput($nom);
        $alcool_1 = $this->secureInput($alcool_1);
        $alcool_2 = $this->secureInput($alcool_2);
        $alcool_3 = $this->secureInput($alcool_3);
        $boisson_soft_1 = $this->secureInput($boisson_soft_1);
        $boisson_soft_2 = $this->secureInput($boisson_soft_2);
        $boisson_soft_3 = $this->secureInput($boisson_soft_3);
        $garniture_1 = $this->secureInput($garniture_1);
        $garniture_2 = $this->secureInput($garniture_2);
        $garniture_3 = $this->secureInput($garniture_3);
        $pourcentage_alcool = $this->secureInput($pourcentage_alcool);

        $sql = "INSERT INTO Cocktails (nom, alcool_1, alcool_2, alcool_3, boisson_soft_1, boisson_soft_2, boisson_soft_3, garniture_1, garniture_2, garniture_3, pourcentage_alcool) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssssssss", $nom, $alcool_1, $alcool_2, $alcool_3, $boisson_soft_1, $boisson_soft_2, $boisson_soft_3, $garniture_1, $garniture_2, $garniture_3, $pourcentage_alcool);
        
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function markAsFavorite($cocktailId) {
        $cocktailId = $this->secureInput($cocktailId);

        // Vérifier si le cocktail existe
        $checkQuery = "SELECT * FROM Cocktails WHERE id = ?";
        $checkStmt = $this->conn->prepare($checkQuery);
        $checkStmt->bind_param("i", $cocktailId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows === 0) {
            return false; // Le cocktail n'existe pas
        }

        // Mettre à jour la colonne favori
        $updateQuery = "UPDATE Cocktails SET favori = 1 WHERE id = ?";
        $updateStmt = $this->conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $cocktailId);

        if ($updateStmt->execute()) {
            return true; // Cocktail marqué comme favori avec succès
        } else {
            return false; // Échec de la mise à jour
        }
    }

    private function secureInput($input) {
        // Implement proper input validation and sanitization to prevent SQLi and XSS
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $input = $this->conn->quote($input);
        return $input;
    }
}
?>