<?php

include 'config.php';
include 'model.php';
include 'view_searchCocktail.php';

$model = CocktailModel::create($conn);
$view = new CocktailView();

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'search':
            if (isset($_POST['query'])) {
                $query = $_POST['query'];
                $cocktails = $model->searchCocktail($query);

                if ($cocktails !== false) {
                    $view->showCocktails($cocktails);
                } else {
                    $view->showErrorMessage("Aucun cocktail trouvé.");
                }
            }
            break;

        case 'add':
            if (isset($_POST['cocktail_data'])) {
                $data = json_decode($_POST['cocktail_data'], true);
                $model->addCocktail($nom, $alcool_1, $alcool_2, $alcool_3, $boisson_soft_1, $boisson_soft_2, $boisson_soft_3, $garniture_1, $garniture_2, $garniture_3, $pourcentage_alcool);
                $view->showSuccessMessage("Cocktail ajouté avec succès !");
            }
            break;

        case 'favorite':
            if (isset($_POST['cocktail_id'])) {
                $cocktailId = $_POST['cocktail_id'];
                $model->markAsFavorite($cocktailId);
                $view->showSuccessMessage("Cocktail marqué comme favori !");
            }
            break;

        default:
            // Handle other actions if needed
            break;
    }
}
?>
