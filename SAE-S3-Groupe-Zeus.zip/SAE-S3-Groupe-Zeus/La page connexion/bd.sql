CREATE TABLE personne(
   id_personne INT,
   nom VARCHAR(50) NOT NULL,
   prenom VARCHAR(50) NOT NULL,
   email VARCHAR(50),
   motDePasse VARCHAR(50),
   PRIMARY KEY(id_personne)
);

INSERT INTO personne(id_personne, nom, prenom, email, motDePasse)
VALUES (0, 'WAGNER', 'Romain', 'romain@gmail.com', '12345678');