<?php
$dsn= "pgsql:host=localhost;dbname=12203457";
$login= "12203457";
$mdp = "125R";
?>