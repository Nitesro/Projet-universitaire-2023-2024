<?php

class Controller_connection extends Controller
{
    public function action_connection()
    {

        $mail = $_POST['identifiant'];
        $password = $_POST['mdp'];
       
        // On récupère le modèle
        $m = Model::getModel();

        if($m->verifyUser($mail, $password)) {
            $this->render('home');
        } 
        else {
            echo 'Erreur de connexion';
        }
    
    }

    public function action_default()
    {
        $this->render('connection');
    }
}
