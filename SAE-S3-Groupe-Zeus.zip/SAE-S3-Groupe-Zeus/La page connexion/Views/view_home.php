<?php require "view_begin.php"; ?>

<h1>Connexion réussi</h1>

<?php require "view_end.php"; ?>