<?php require "view_begin.php"; ?>


<div class="img-container">
    <img class="logo" src="img/logo.png" alt="logo">
    </div>

    <div class="container">
        <div class="form-container">
            <h2>Connexion</h2>

            <form action="?controller=connection&action=connection" method="post"class="form-login">

                <div class="input-container">
                
                <div class="id-container">
                <label>Identifiant</label><br>
                <input type="text" name="identifiant"><br>
                </div>

                <div class="mdp-container">
                <label>Mot de passe</label><br>
                <input type="password" name="mdp">
                </div>

                </div>

                <p class="mdp-oublie">Vous avez oublié votre mot de passe?</p>

                <div class="button-container">
                    <button type="submit" class="connecter">Se connecter</button>
                </div>
            </form>
        </div>
    </div>

<?php require "view_end.php"; ?>