<?php

$mdp =  "directorpass";
$passwordencrypt = password_hash($mdp,  PASSWORD_DEFAULT);

echo $passwordencrypt;