<?php

//Le fichier Model qui contient les requetes pour ajouter à la base de données et recuperer 
require "Model.php";

//Definir les variables qu'on va ajouter dans la base de données
$nom = "VILVARAJAH";
$prenom = "vithurzen";
$mail = "vithurzen517@gmail.com";
$password = "sdgds@43634";

//Charger les clés publiques et privées à partir des fichiers PEM
$publickey = openssl_pkey_get_public("file://publickey.pem");
$privatekey = openssl_pkey_get_private("file://privatekey.pem");

//Chiffrer le mot de passe avec la clé publique et mettre dans une variable
openssl_public_encrypt($password, $pwd_encrypted, $publickey);

// Convertir le mot de passe chiffré en base64
$pwd_encrypted_base64 = base64_encode($pwd_encrypted);

// Afficher le mot de passe chiffré
echo "Motdepasse chiffré : " . $pwd_encrypted_base64; ?> </br>

<?php 
// Ajouter le mot de passe chiffrées à la base de données via l'objet Model
$m = Model::getmodel();

//Récupérer le mot de passe chiffré depuis la base de données
$m->addEncryptedData($nom, $prenom, $mail, $pwd_encrypted_base64);

//recuprer le mot de passe chiffré depuis la base de données et mettre dans une variable
$pwd_encrypted_from_DB = $m->getEncryptedPassword($nom);
$pwd_encrypted_from_DB = stream_get_contents($pwd_encrypted_from_DB['motdepasse']);

//Déchiffrer le mot de passe avec la clé privée
openssl_private_decrypt(base64_decode($pwd_encrypted_from_DB), $pwd_decrypted, $privatekey);

//Afficher le mot de passe déchiffré
echo "Motdepasse dechiffré : ". $pwd_decrypted;

?>
