<?php

class Model
{
    /**
     * Attribut contenant l'instance PDO
     */
    private $bd;

    /**
     * Attribut statique qui contiendra l'unique instance de Model
     */
    private static $instance = null;

    /**
     * Constructeur : effectue la connexion à la base de données.
     */
    private function __construct()
    {
        include "credentials.php";
        $this->bd = new PDO($dsn, $login, $mdp);
        $this->bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->bd->query("SET nameS 'utf8'");
    }

    /**
     * Méthode permettant de récupérer un modèle car le constructeur est privé (Implémentation du Design Pattern Singleton)
     */
    public static function getModel()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
        /**
     * Ajoute les données chiffrées d'un utilisateur à la base de données.
     *
     * @param string $nom - Nom de l'utilisateur.
     * @param string $prenom - Prénom de l'utilisateur.
     * @param string $mail - Adresse mail de l'utilisateur.
     * @param string $pwd - Mot de passe chiffré de l'utilisateur.
     *
     * @return bool - Indique si l'insertion a réussi (true) ou non (false).
     */
    public function addEncryptedData($nom, $prenom, $mail, $pwd) {
        // Préparation de la requête SQL pour l'insertion des données
            $req = $this->bd->prepare('INSERT INTO personne (nom, prenom, email, motDePasse) VALUES (:nom, :prenom, :mail, :password)');
        
            $req->bindParam(':nom', $nom);
            $req->bindParam(':prenom', $prenom);
            $req->bindParam(':mail', $mail);
            $req->bindParam(':password', $pwd);
        // Exécution de la requête
            $req->execute();
        // Retourne un booléen indiquant si l'insertion a réussi
            return (bool) $req->rowCount();
    }

    /**
     * Récupère le mot de passe chiffré d'un utilisateur à partir de la base de données.
     *
     * @param string $nom - Nom de l'utilisateur.
     *
    */
    public function getEncryptedPassword($nom) {
        // Préparation de la requête SQL pour récupérer le mot de passe chiffré à partir du nom
        $req = $this->bd->prepare('SELECT motdepasse FROM personne WHERE nom = :nom');
        $req->bindParam(':nom', $nom);

        // Exécution de la requête
        $req->execute();
        $result = $req->fetch(PDO::FETCH_ASSOC);
        
        // Retourne le résultat (mot de passe chiffré)
        return $result;

    }

}
?>