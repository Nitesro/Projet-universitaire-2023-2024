<!DOCTYPE html>
<html>
<head>
    <title>Crible d'Ératosthène</title>
    <style>
        .form-container {
            display: flex;
            justify-content: space-around;
        }
        .form-container form {
            margin: 15px;
        }
    </style>
</head>
<body>
    <?php
    $message = '';
    $nombresPremiers = [];
    $tempsExecution = 0;
    $consommationMemoire = 0;
    // Première version du calcul d'Ératosthène 
    function eratonormal($n) {
        $a = range(2, $n);
        $div = 2;   
        while ($div < count($a)) {
            $i = $div;
            
            while ($i < count($a)) {
                if ($a[$i] % $div == 0) {
                    array_splice($a, $i, 1);
                } else {
                    $i++;
                }
            }
            $div++;
        }
        return $a;
    }
    // Version optimisé (correction en TP crypto)
    function eratoopti($n) {
            if ($n < 2) {
                return [];
            }
        
            $listeNombres = array_fill(0, $n, true);
            $nombresPremiers = [];
        
            $listeNombres[0] = $listeNombres[1] = false; // 0 et 1 ne sont pas des nombres premiers
        
            for ($p = 2; $p * $p <= $n; $p++) {
                if ($listeNombres[$p]) {
                    for ($i = $p * $p; $i < $n; $i += $p) {
                        $listeNombres[$i] = false;
                    }
                }
            }
        
            foreach ($listeNombres as $index => $estPremier) {
                if ($estPremier) {
                    $nombresPremiers[] = $index;
                }
            }
            
            return $nombresPremiers;
        
    }

    if ($_SERVER["REQUEST_METHOD"] == 'POST') {
        if (isset($_POST['nombre']) && $_POST['nombre'] !== '' && is_numeric($_POST['nombre']) && $_POST['nombre'] < 100000000) {
            $debut = microtime(true); // Commencer le temps
            $memoireDebut = memory_get_usage(); // Commencer le calcul de consomation

            if (isset($_POST['opti'])) {
                $nombresPremiers = eratoopti($_POST['nombre']);
            } elseif (isset($_POST['normal'])) {
                $nombresPremiers = eratonormal($_POST['nombre']);
            }

            $fin = microtime(true); // Fin temps
            $memoireFin = memory_get_usage(); // Fin conso

            $tempsExecution = $fin - $debut; // Calcul du temps
            $consommationMemoire = $memoireFin - $memoireDebut; // Calcul de la consommation
        } else {
            $message = "Veuillez rentrer un nombre valide et inférieur à 100 000 000.";
        }
    }
    ?>

<div class="form-container">
        <div>
            <p>Calcul du Crible d'Ératosthène version optimisée</p>
            <form action="" method="POST">
                <input type="text" name="nombre" placeholder="Entrez un chiffre">
                <input type="hidden" name="opti" value="1">
                <input type="submit" value="Calculer">
            </form>
        </div>
        <div>
            <p>Calcul du Crible d'Ératosthène sans optimisation</p>
            <form action="" method="POST">
                <input type="text" name="nombre" placeholder="Entrez un chiffre">
                <input type="hidden" name="normal" value="1">
                <input type="submit" value="Calculer">
            </form>
        </div>
    </div>

    <?php if (isset($tempsExecution)): ?>
        <p>Temps d'exécution: <?php echo $tempsExecution; ?> secondes</p>
        <p>Consommation mémoire: <?php echo $consommationMemoire; ?> octets</p>
    <?php endif; ?>
    <?php if (!empty($nombresPremiers)): ?>
    <?php elseif ($_SERVER["REQUEST_METHOD"] == 'POST'): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

</body>
</html>
