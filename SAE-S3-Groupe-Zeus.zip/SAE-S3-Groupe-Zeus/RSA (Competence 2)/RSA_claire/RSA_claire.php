<?php
function est_premier($n) {
    if ($n <= 1) {
        return false;
    }
    for ($i = 2; $i <= sqrt($n); $i++) {
        if ($n % $i == 0) {
            return false;
        }
    }
    return true;
}
function generer_nombre_premier($minimum, $maximum) {
    $nombre = rand($minimum, $maximum);
    while (!est_premier($nombre)) {
        $nombre = rand($minimum, $maximum);
    }
    return $nombre;
}

function pgcd($a, $b) {
    while ($b) {
        list($a, $b) = array($b, $a % $b);
    }
    return $a;
}

function inverser_modulo($a, $m) {
    $m0 = $m;
    $x0 = 0;
    $x1 = 1;
    while ($a > 1) {
        $q = intval($a / $m);
        list($m, $a) = array($a % $m, $m);
        list($x0, $x1) = array($x1 - $q * $x0, $x0);
    }
    return ($x1 + $m0) % $m0;
}

function generer_cles_rsa() {
    // Choisissez deux nombres premiers aléatoires
    $p = generer_nombre_premier(50, 100);
    $q = generer_nombre_premier(100, 150);

    // Calculez n et phi(n)
    $n = $p * $q;
    $phi_n = ($p - 1) * ($q - 1);

    // Choisissez un exposant public e (doit être premier avec phi(n))
    $e = generer_nombre_premier(2, $phi_n);

    // Calculez l'exposant privé d
    $d = inverser_modulo($e, $phi_n);

    // Retournez les clés publique et privée
    return array('public' => array('n' => $n, 'e' => $e), 'private' => array('n' => $n, 'd' => $d));
}



// Fonction de chiffrement RSA pour les entiers
function chiffrer_rsa_entier($message, $cle_publique) {
    $n = $cle_publique['n'];
    $e = $cle_publique['e'];
    return bcpowmod($message, $e, $n);
}

// Fonction de déchiffrement RSA pour les entiers
function dechiffrer_rsa_entier($message_chiffre, $cle_privee) {
    $n = $cle_privee['n'];
    $d = $cle_privee['d'];
    return bcpowmod($message_chiffre, $d, $n);
}

// Fonction de chiffrement RSA pour les chaînes de caractères
function chiffrer_rsa_chaine($message, $cle_publique) {
    $n = $cle_publique['n'];
    $e = $cle_publique['e'];
    $message_chiffre = '';
    for ($i = 0; $i < strlen($message); $i++) {
        $char = ord($message[$i]);
        $char_chiffre = bcpowmod($char, $e, $n);
        $message_chiffre .= $char_chiffre . ' ';
    }
    return trim($message_chiffre);
}

// Fonction de déchiffrement RSA pour les chaînes de caractères
function dechiffrer_rsa_chaine($message_chiffre, $cle_privee) {
    $n = $cle_privee['n'];
    $d = $cle_privee['d'];
    $message_dechiffre = '';
    $chiffres = explode(' ', $message_chiffre);
    foreach ($chiffres as $chiffre) {
        $char_dechiffre = bcpowmod($chiffre, $d, $n);
        $message_dechiffre .= chr($char_dechiffre);
    }
    return $message_dechiffre;
}

// Générer les clés RSA
$cles = generer_cles_rsa();

// Message à chiffrer (entier)
$message_entier_original = 42;

// Chiffrer le message (entier)
$message_entier_chiffre = chiffrer_rsa_entier($message_entier_original, $cles['public']);

// Afficher le message chiffré (entier)
echo "Message chiffré (entier): " . $message_entier_chiffre ; ?> <br> <?php

// Déchiffrer le message (entier)
$message_entier_dechiffre = dechiffrer_rsa_entier($message_entier_chiffre, $cles['private']);

// Afficher le message déchiffré (entier)
echo "Message déchiffré (entier): " . $message_entier_dechiffre; ?> <br> <?php

// Message à chiffrer (chaîne de caractères)
$message_chaine_original = "Hello M Hebert";

// Chiffrer le message (chaîne de caractères)
$message_chaine_chiffre = chiffrer_rsa_chaine($message_chaine_original, $cles['public']);

// Afficher le message chiffré (chaîne de caractères)
echo "Message chiffré (chaîne): " . $message_chaine_chiffre; ?> <br> <?php

// Déchiffrer le message (chaîne de caractères)
$message_chaine_dechiffre = dechiffrer_rsa_chaine($message_chaine_chiffre, $cles['private']);

// Afficher le message déchiffré (chaîne de caractères)
echo "Message déchiffré (chaîne): " . $message_chaine_dechiffre;


?>
