simple_fetch('chat.php?action=nom').then(reponse=>{
    const nom=document.getElementById('nom');
    nom.value=reponse.nom;
  });
  document.getElementById('changer-nom').addEventListener('click',()=>{
    const nom=document.getElementById('nom').value;
    console.log(nom);
  })