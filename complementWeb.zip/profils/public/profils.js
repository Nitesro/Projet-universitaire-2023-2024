const principal     =document.getElementById('profil-principal');
const liste         =document.getElementById('liste');
const formulaire    =document.getElementById('formulaire');

// Chercher les noms pour créer la liste en haut de la page
const noms=await simple_fetch('profil');
for(const [id,nom] of Object.entries(noms)){
  const li=document.createElement('li');
  li.setAttribute('data-id',id);
  li.textContent=nom;
  liste.append(li);
}

// Afficher le profil quand l'utilisateur clique sur un nom
liste.addEventListener('click',(event)=>{
  if(event.target.nodeName!=='LI'){return;}
  const id=event.target.getAttribute('data-id');
  afficher_profil(id);
});

async function afficher_profil(id){
  principal.style.display='block';
  const profil=await simple_fetch('profil/'+id);
  principal.setAttribute('data-id',id);
  principal.querySelector('.nom'        ).textContent=profil.nom;
  principal.querySelector('.portrait'   ).src=profil.portrait;
  principal.querySelector('.portrait'   ).className='portrait '+profil.sexe;
  principal.querySelector('.messages'   ).textContent=profil.messages+' messages';
  principal.querySelector('.likes'      ).textContent=profil.likes+' likes';
  principal.querySelector('.description').textContent=profil.description;
}

// Afficher et remplir le formulaire quand l'utilisateur clique sur editer
document.getElementById('editer').addEventListener('click',async ()=>{
  const id=principal.getAttribute('data-id');
  const profil=await simple_fetch('profil/'+id);
  formulaire.style.display='block';
  formulaire.setAttribute('data-id',id);
  document.getElementById('edit-nom'        ).value=profil.nom;
  document.getElementById('edit-sexe'       ).value=profil.sexe;
  document.getElementById('edit-portrait'   ).value=profil.portrait;
  document.getElementById('edit-messages'   ).value=profil.messages;
  document.getElementById('edit-likes'      ).value=profil.likes;
  document.getElementById('edit-description').value=profil.description;
});

// Envoyer le profil edit par POST au serveur quand l'utilisateur clique sur enregistrer
document.getElementById('enregistrer').addEventListener('click',async ()=>{
  const id=formulaire.getAttribute('data-id');
  const profil={id};
  profil.nom        =document.getElementById('edit-nom'        ).value;
  profil.sexe       =document.getElementById('edit-sexe'       ).value;
  profil.portrait   =document.getElementById('edit-portrait'   ).value;
  profil.messages   =document.getElementById('edit-messages'   ).value;
  profil.likes      =document.getElementById('edit-likes'      ).value;
  profil.description=document.getElementById('edit-description').value;
  await simple_fetch('profil/'+id,{post:profil});  
  formulaire.style.display='none';
  afficher_profil(id);  
});

document.getElementById('fermer').addEventListener('click',()=>{
  formulaire.style.display='none';
});