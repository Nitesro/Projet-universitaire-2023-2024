
<?php
$dsn='pgsql:host=localhost;dbname=SAES4';
$login='postgres';
$mdp='root';
?>