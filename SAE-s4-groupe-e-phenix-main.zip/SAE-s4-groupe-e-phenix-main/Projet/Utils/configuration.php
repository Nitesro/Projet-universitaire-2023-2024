<?php
/**
 * Élement de configuration comme par exemple les chemins vers des dossiers
 */
$cheminBdl = '../BDL/';