

<footer >
<div class="nom-entreprise"><img src="Content\images\Logo.png" class="imglogo"/></div>    <div class="info-entreprise"><a href="#">Mentions Légales</a></div>
    <div class="info-entreprise"><a href="#">Informations sur l'entreprise</a></div>
</footer>
</body>
<script src="Content/js/main.js"></script>
</html>
