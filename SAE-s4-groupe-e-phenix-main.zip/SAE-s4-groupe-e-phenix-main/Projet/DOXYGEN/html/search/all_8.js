var searchData=
[
  ['hasseveralroles_0',['hasSeveralRoles',['../class_model.html#a9909b26625ede8ad2a95bcf334cd87fc',1,'Model']]]
];
