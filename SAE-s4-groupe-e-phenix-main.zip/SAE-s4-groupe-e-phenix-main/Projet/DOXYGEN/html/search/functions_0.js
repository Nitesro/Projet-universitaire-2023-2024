var searchData=
[
  ['_5f_5fconstruct_0',['__construct',['../class_controller.html#a095c5d389db211932136b53f25f39685',1,'Controller']]]
];
