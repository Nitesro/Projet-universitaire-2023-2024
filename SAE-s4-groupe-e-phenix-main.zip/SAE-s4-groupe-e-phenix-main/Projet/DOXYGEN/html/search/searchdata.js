var indexSectionsWithContent =
{
  0: "$_acdefghilmprstv",
  1: "cm",
  2: "cfimrv",
  3: "_acdeghimrst",
  4: "$_efi",
  5: "ept"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

