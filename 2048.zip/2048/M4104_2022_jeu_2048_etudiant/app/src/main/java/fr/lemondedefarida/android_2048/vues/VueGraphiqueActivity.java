package fr.lemondedefarida.android_2048.vues;

import java.util.Observable;
import java.util.Observer;

import android.app.Activity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.widget.TextView;
import fr.lemondedefarida.android_2048.R;

public class VueGraphiqueActivity extends Activity implements Observer {

	// Modele
	/**
	 * A decommenter quand la bibliotheque modele_2048.jar sera liée à ce projet Android Studio
	 */
	//private GameManager mGameManager;



	private TextView mTvScore;
	private TextView mTvSwipes;
	private TextView mTvRestart;
	private TextView mTvModeTexte;
	private TextView mTvMenuGeneral;




	private GestureDetector mGestureDetector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_vue_graphique);

	}
	@Override
	protected void onDestroy() {
		super.onDestroy();

	}



	/**
	 * 
	 * Vue graphique
	 */

	private void deserialisationVue(){



	}

	private void initConnections(){


	}




	





	@Override
	public void update(Observable observable, Object data) {
		/**
		 * Design pattern Observateur
		 *
		 * Méthode appelée à chaque changement d'état du modèle
 		 */



	}




}
