package fr.dev_mobile.display_number;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import fr.m4104.display_number.R;

/**
 * @author B. LEMAIRE
 * Activité pour la saisi d'un nombre entier
 */
public class MainActivity extends Activity {
    // Pour la saisi du nombre
    private EditText et_number;

    // Bouton pour l'affichage
    private Button bt_dispay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Désérialisation des ressources
        deserialiserRessources();

        // Mise en place de l'écouteur du bouton
        initConnection();
    }

    private void deserialiserRessources() {
        et_number = findViewById(R.id.et_number);
        bt_dispay = findViewById(R.id.bt_display);
    }

    private void initConnection() {
        bt_dispay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sNb = et_number.getText().toString();
                try {
                    int number = Integer.parseInt(sNb);
                    Intent intent = new Intent(MainActivity.this, Display.class);
                    intent.putExtra("number", number);
                    startActivity(intent);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, R.string.invalid_number, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}