package fr.dev_mobile.display_number;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import fr.m4104.display_number.R;

/**
 * @author B. LEMAIRE
 * Activité pour l'affichage d'un nombre entier
 */
public class Display extends Activity {

    // Pour l'affichage du nombre
    private TextView tv_display_number;
    private Button bt_fin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);

        // Désérialisation des ressources
        deserialiserRessources();
        // Mise en place de l'écouteur du bouton
        initConnection();

        // Récupération de l'Intent qui a servi à lancer cette activité
        Intent intent = getIntent();

        // Récupération des extras
        if (intent != null && intent.hasExtra("number")) {
            // Récupération du nombre à partir des extras
            int number = intent.getIntExtra("number", 0); // 0 est la valeur par défaut si l'extra n'est pas trouvé

            // Affichage du nombre dans le TextView
            tv_display_number.setText(String.valueOf(number));
        }

    }

    private void deserialiserRessources() {
        tv_display_number = findViewById(R.id.tv_display);
        bt_fin = findViewById(R.id.bt_fin);
    }

    /**
     * fin de l'activiter
     * */

    private void initConnection() {
        bt_fin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
